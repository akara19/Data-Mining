<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "1986",
    'dbname' => "apriori_toko_parfum",
    // 'port' => "", // sementara menggunakan port bawaan
);

?>
