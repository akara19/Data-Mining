<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
            <span class="bigger-120">
                <span class="blue bolder">Data Mining</span>
                Apriori Toko Parfum &copy; 2017 | Distributed by <a href="https://blogbugabagi.blogspot.com" target="_blank" rel="noopener noreferrer">BlogBugaBagi</a>
            </span>
        </div>
    </div>
</div>