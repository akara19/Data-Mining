<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="page-header">
                <h1>
                    Halaman Utama
                </h1>
            </div><!-- /.page-header -->

            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->


                    <div class="row">
                        <center>
                            <h1>
                                Implementasi Data Mining 
                                <br>
                                pada Penentuan Merk Parfum 
                                yang banyak Terjual dengan Algoritma Apriori
                            </h1>
                            <p>
                            <h2>
                                (Studi Kasus: Copa Gabana Parfum Cabang Sentolang Gresik)
                            </h2>
                            </p>
                        </center>

                    </div><!-- /.row -->

                    <div class="hr hr32 hr-dotted"></div>

                    <!-- PAGE CONTENT ENDS -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->
